-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 05, 2017 at 02:38 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shbllc`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `blog` longtext NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `name`, `blog`, `created`, `modified`) VALUES
(1, 'test page 1', '<p>okjay<img class="" src="/files/random%20images/elitelacross.jpg" alt="" width="496" height="110" /></p>\r\n<p>okay</p>', '2017-06-30 15:07:06', '2017-07-17 17:49:10'),
(2, 'test2', '<p>test test etst</p>', '2017-07-17 17:51:39', '2017-07-17 17:51:39');

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `page_type` varchar(255) NOT NULL DEFAULT 'content',
  `linked_gallery` varchar(255) DEFAULT NULL,
  `available` varchar(50) NOT NULL DEFAULT 'content'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `name`, `content`, `created`, `modified`, `page_type`, `linked_gallery`, `available`) VALUES
(7, 'Home', '<div class="hm_columns show_xs show_sm show_md show_lg col-xs-12 col-sm-12 col-lg-6 col-md-6 f_left animated fadeInUp visible" data-animation="fadeInUp" data-animation-delay="100">\r\n<div class="hm_column_out column_spacer1">\r\n<div class="hm_column_con clearfix col_padd1 radius5">\r\n<h2 class="main_title title_boxed no_border no_line align_left tb_space25">WHY WE CUSTOM BUILD?</h2>\r\n<div class="hm_text_sc fs15">\r\n<p>We do custom home building and have been for over 20 Years. We do custom home building and have been for over 20 Years. We do custom home building and have been for over 20 Years. We do custom home building and have been for over 20 Years.</p>\r\n</div>\r\n<br /><br />\r\n<div class="main_title title_boxed no_border no_line align_left tb_space25">\r\n<h2 class="upper fs24 bold2">REALTOR INCENTIVE PROGRAM</h2>\r\n</div>\r\n<div class="hm_text_sc fs15">\r\n<p>We do custom home building and have been for over 20 Years. We do custom home building and have been for over 20 Years. We do custom home building and have been for over 20 Years. We do custom home building and have been for over 20 Years. ok</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>', '2017-07-13 16:25:02', '2017-08-10 17:12:53', 'content', '', 'no'),
(14, 'Whybuildwithus', '<p>Why Build with us?</p>', '2017-08-10 15:02:19', '2017-08-10 15:02:19', 'content', '', 'no'),
(3, 'Our Mission', '<p>This is our mission, should we choose to accept it.</p>\r\n<p>&nbsp;Yeah, that about covers it -&nbsp;<br />Blah Blah</p>', '2017-06-29 20:12:18', '2017-06-29 20:48:40', 'content', NULL, 'content'),
(4, 'What We Do', '<p>some more stuff.</p>', '2017-06-29 20:12:31', '2017-06-29 20:12:31', 'content', NULL, 'content'),
(5, 'Client Testimonials', '<h2>&nbsp;Testimonial 1 Testimonial 1 Testimonial 1 Testimonial 1 Testimonial 1 Testimonial 1</h2>\r\n<p>Test Test Test Test</p>\r\n<h2>Testimonial 2</h2>\r\n<p>Test2&nbsp;Test2&nbsp;Test2&nbsp;Test2&nbsp;</p>', '2017-06-29 20:13:35', '2017-06-30 12:55:13', 'content', '', 'content'),
(6, 'House 123', '<p><img class="" src="/files/random%20images/elitelacross.jpg" alt="" width="496" height="110" /></p>\r\n<p>This is some info on the house. Blah Blah Blah.</p>', '2017-06-29 21:11:30', '2017-09-28 20:14:40', 'house', '123 House Dr', 'yes'),
(8, 'House 456', '<p>Test for House456</p>', '2017-08-09 15:02:50', '2017-09-28 20:14:34', 'house', '456 House Dr', 'no'),
(9, 'Stone House Difference', '<p>The difference with Stone House Builders LLC is blah blah blah</p>', '2017-08-09 15:23:15', '2017-08-09 15:23:15', 'content', '', 'no'),
(10, 'Building Process', '<p>Our Building Process is blah blah blah</p>', '2017-08-09 15:23:38', '2017-08-09 15:23:38', 'content', '', 'no'),
(11, 'Build With Us', '<p>Build with us</p>', '2017-08-09 15:23:57', '2017-08-09 15:23:57', 'content', '', 'no'),
(12, 'Build on Your Lot', '<p>We can build on your lot or ours, but if we build on yours we blah blah blah</p>', '2017-08-09 15:24:25', '2017-08-09 15:24:25', 'content', '', 'no'),
(13, 'Biography', '<p>This is the biography.</p>', '2017-08-09 15:24:56', '2017-08-09 15:24:56', 'content', '', 'no'),
(15, 'Random House', '<p>Buy me Damnit</p>', '2017-10-03 22:38:23', '2017-10-03 22:38:23', 'house', '123 House Dr', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `galleries`
--

CREATE TABLE `galleries` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `folder` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `galleries`
--

INSERT INTO `galleries` (`id`, `name`, `folder`, `created`, `modified`) VALUES
(1, '123 House Dr', '123 House Dr', '2017-07-17 00:00:00', '2017-07-17 00:00:00'),
(3, '456 House Dr', '456 House Dr', '2017-07-17 00:00:00', '2017-07-17 00:00:00'),
(4, '123 House Dr', '123 House Dr', '2017-10-03 22:38:23', '2017-10-03 22:38:23');

-- --------------------------------------------------------

--
-- Table structure for table `gallery_images`
--

CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL,
  `gallery_id` int(11) NOT NULL,
  `src` text NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `body` longtext,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created`, `modified`, `user_id`) VALUES
(1, 'Test1', 'Testing', '2017-06-29 13:22:39', '2017-06-29 13:22:39', NULL),
(2, 'Test2', 'Testies', '2017-06-29 13:22:52', '2017-06-29 13:22:52', NULL),
(3, 'Test3', 'Tastey', '2017-06-29 13:23:09', '2017-06-29 13:23:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created`, `modified`) VALUES
(2, 'ericbloom', '$2a$10$D3MaYxUR0izpQXcGMmeaUOiROs38Foii.mCTBMlS9RwZRH.G1F57S', 'admin', '2017-06-30 12:06:27', '2017-06-30 12:06:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `gallery_images`
--
ALTER TABLE `gallery_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `gallery_images`
--
ALTER TABLE `gallery_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
